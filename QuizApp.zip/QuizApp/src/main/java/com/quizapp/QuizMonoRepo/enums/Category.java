package com.quizapp.QuizMonoRepo.enums;

public enum Category {
JAVA,HTML,MYSQL
}
