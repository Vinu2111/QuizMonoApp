package com.quizapp.QuizMonoRepo.enums;

public enum DifficultyLevel {
EASY,MEDIUM,HIGH
}
